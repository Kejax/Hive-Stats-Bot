from flask import Flask
from threading import Thread
import random
import time

print_guild = None

app = Flask('')

@app.route('/')
def home():
	return 'Im in!\n' + str(print_guild.print_guilds)

def run():
  app.run(
		host='0.0.0.0',
		port=random.randint(2000,9000)
	)

def keep_alive(bot):
  global print_guild
  print_guild = bot
  '''
	Creates and starts new thread that runs the function run.
	'''
  t = Thread(target=run)
  t.start()