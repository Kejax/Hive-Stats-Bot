import os
import discord
from keep_alive import keep_alive
from discord.ext import commands, tasks
import asyncio
from replit import db
from Hive.Player import Player

def is_linked(discord_id):
  try:
    playerlink = db["playerlink-" + str(discord_id)]
    if not playerlink == None:
      return True
    else:
      return False
  except Exception:
    return False

def get_link(discord_id):
  playerlink = db["playerlink-" + str(discord_id)]
  return playerlink


def write_link(discord_id, player_name):
  db["playerlinks-" + str(discord_id)] = player_name



new_version = True
intents = discord.Intents().all()

bot = commands.Bot(
	command_prefix="h!",  # Change to desired prefix
	case_insensitive=True,  # Commands aren't case-sensitive
  #help_command=None#, intents=intents
)

bot.author_id = 538029972791492609  # Change to your discord id!!!

@bot.event 
async def on_ready():  # When the bot is ready
    print("I'm in")
    print(bot.user)  # Prints the bot's username and identifier
    print(len(bot.guilds))
    bot.print_guilds = []
    for guild in bot.guilds:
      print(guild.name)
      bot.print_guilds.append(guild.name)
    if new_version == True:
      update_status.start()
    else:
      version_status.start()

#@bot.event
async def on_command_error(ctx, error):
  return
  if isinstance(error, commands.CommandNotFound):
    error = str(error)
    error = error.split("\"")[1] 
    em = discord.Embed(title=f"Fehler!", description=f"Befehl `{error}` wurde nicht gefunden", color=ctx.author.color) 
    await ctx.channel.send(embed=em)

@tasks.loop(seconds=15)
async def update_status():
  await bot.change_presence(activity=discord.Game("Big Update incoming!"), status=discord.Status.dnd)
  await asyncio.sleep(5)
  await bot.change_presence(activity=discord.Game("Leaderboard support soon"), status=discord.Status.dnd)
  await asyncio.sleep(5)
  await bot.change_presence(activity=discord.Game(f"On {len(bot.guilds)} Servers"), status=discord.Status.dnd)
  await asyncio.sleep(5)
  
@tasks.loop(seconds=30.0)
async def version_status():
  await bot.change_presence(activity=discord.Game("V 0.1.2"), status=discord.Status.online)
  await asyncio.sleep(15)
  await bot.change_presence(activity=discord.Game("Hilfe? hive/help"), status=discord.Status.online)

extensions = [
  #"cogs.Hivestats",  # Same name as it would be if you were importing it
  "cogs.HiveCog"
]

if __name__ == '__main__':  # Ensures this is the file being ran
	for extension in extensions:
		bot.load_extension(extension)  # Loades every extension.

keep_alive(bot)  # Starts a webserver to be pinged.
token = os.environ.get("DISCORD_BOT_SECRET") 
bot.run(token)  # Starts the bot