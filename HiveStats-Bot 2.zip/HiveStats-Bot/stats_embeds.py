import discord
from discord.ext import commands
import requests
import json
from language_get import *





async def bedwars(ctx, player):

  #if get_lang(ctx.guild.id) == "de":
  player_link = player.replace(" ", "%20")
  stats_request = requests.get(f"https://api.playhive.com/v0/game/all/wars/{player_link}") 
  stats = stats_request.json()
  Stats_Embed = discord.Embed(title=f"TheHive Stats - {player} - Treasure Wars", color=15844367)
  Stats_Embed.add_field(name="XP", value=stats["xp"], inline=False)
  Stats_Embed.add_field(name="Wins", value=stats["victories"], inline=True)    
  Stats_Embed.add_field(name="Games", value=stats["played"], inline=True)
  Stats_Embed.add_field(name="Kills", value=stats["kills"], inline=True)
  Stats_Embed.add_field(name="Final Kills", value=stats["final_kills"], inline=True)
  Stats_Embed.add_field(name="Deaths", value=stats["deaths"], inline=True)
  Stats_Embed.add_field(name="Treasures", value=stats["treasure_destroyed"], inline=True)
  Stats_Embed.set_footer(text="TheHive Stats Bot by Kejax Innovations\nhive/help für Hilfe", icon_url="https://www.dropbox.com/s/houd16570trau3v/Kejax_Inno_Logo.png?dl=1")
  await ctx.channel.send(embed=Stats_Embed)