import requests
import json

class Leaderboard:

  def __init__(self):
    self.bedwars = Bedwars()
  