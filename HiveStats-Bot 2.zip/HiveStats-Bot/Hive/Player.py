import aiohttp
import json
import datetime

BEDWARS_URL = "https://api.playhive.com/v0/game/all/wars/"
SKYWARS_URL = "https://api.playhive.com/v0/game/all/sky/"
DEATHRUN_URL = "https://api.playhive.com/v0/game/all/dr/"
HIDE_AND_SEEK_URL = "https://api.playhive.com/v0/game/all/hide/"
SURVIVAL_GAMES_URL = "https://api.playhive.com/v0/game/all/sg/"
MURDER_MYSTERY_URL = "https://api.playhive.com/v0/game/all/murder/"


class Player:
	def __init__(self, playername=None, data=None):
		if not playername == None:
			playername = playername.replace(" ", "%20")
	self.bedwars = Bedwars(playername)
	self.treasure_wars = Bedwars(playername)
	self.sky_wars = SkyWars(playername)
	self.death_run = DeathRun(playername)
	self.hide_and_seek = HideAndSeek(playername)
	self.survival_games = SurvivalGames(playername)


class Bedwars:
	def __init__(self, playername=None, data=None):
		self.playername = playername
		self.data = data
	
	async def init(self):
		if not self.playername == None:
			async with aiohttp.ClientSession() as session:
				async with session.get(BEDWARS_URL + self.playername) as response:
					self.data = await response.json()
		self.experience = self.data["xp"]	
		self.played = self.data["played"] 
		self.victories = self.data["victories"]
		self.first_played = self.data["first_played"]
		self.final_kills = self.data["final_kills"]
		self.kills = self.data["kills"]
		self.treasures_destroyed = self.data["treasure_destroyed"]
		self.deaths = self.data["deaths"]
  
class SkyWars:
	def __init__(self, playername=None, data=None):
		if not playername == None:
			request = requests.get(SKYWARS_URL + playername)
			self.data = request.json()
		else:
			self.data = data
			self.experience = self.data["xp"]
			self.played = self.data["played"]
			self.victories = self.data["victories"]
			self.first_played = self.data["first_played"]
			self.mystery_chests_destroyed = self.data["mystery_chests_destroyed"]
			self.ores_mined = self.data["ores_mined"]
			self.spells_used = self.data["spells_used"]

class DeathRun:
	def __init__(self, playername=None, data=None):
		if not playername == None:
			request = requests.get(DEATHRUN_URL + playername)
			self.data = request.json()
		else:
			self.data = data
		self.experience = self.data["xp"]
		self.played = self.data["played"]
		self.victories = self.data["victories"]
		self.first_played = self.data["first_played"]
		self.deaths = self.data["deaths"]
		self.checkpoints = self.data["checkpoints"]
		self.activated = self.data["activated"]
		self.kills = self.data["kills"]

class HideAndSeek:
	def __init__(self, playername=None, data=None):
		if not playername == None:
			request = requests.get(HIDE_AND_SEEK_URL + playername)
			self.data = request.json()
		else:
			self.data = data
		self.experience = self.data["xp"]
		self.played = self.data["played"]
		self.victories = self.data["victories"]
		self.first_played = self.data["first_played"]
		self.deaths = self.data["deaths"]
		self.hider_kills = self.data["hider_kills"]
		self.seeker_kills = self.data["seeker_kills"]

class SurvivalGames:
	def __init__(self, playername=None, data=None):
		if not playername == None:
			request = requests.get(SURVIVAL_GAMES_URL + playername)
			self.data = request.json()
		else:
			self.data = data
			self.experience = self.data["xp"]
			self.played = self.data["played"]
			self.victories = self.data["victories"]
			self.first_played = self.data["first_played"]
			self.crates = self.data["crates"]
			self.deathmatches = self.data["deathmatches"]
			self.cows = self.data["cows"]
			self.kills = self.data["kills"]

class MurderMystery:
	def __init__(self, playername=None, data=None):
		if not playername == None:
			request = requests.get(MURDER_MYSTERY_URL + playername)
			self.data = request.json()
		else:
			self.data = data
			self.experience = self.data["xp"]
			self.played = self.data["played"]
			self.victories = self.data["victories"]
			self.first_played = self.data["first_played"]
			self.deaths = self.data["deaths"]
			self.coins = self.data["coins"]
			self.murders = self.data["murders"]
			self.murderer_eliminations = self.data["murderer_eliminations"]
			self.uncapped_xp = self.data["uncapped_xp"]