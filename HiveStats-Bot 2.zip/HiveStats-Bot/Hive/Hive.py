from .Player import Player
from .Leaderboard import Leaderboard
#from .TimeLeaderboard import TimeLeaderboard
#from .MonthlyLeaderboard import MonthlyLeaderboard

class Hive:
  def __init__(self):
    self.player = Player
    self.leaderboard = Leaderboard
    #self.monthly_leaderboard = MonthlyLeaderboard
    #self.leaderboard_from_time = TimeLeaderboard