import discord
import json
from Languages import German

Lang = {"DE": German}

def write_language(guild : discord.Guild, lang="EN"):
  with open("lang_settings.json", "r") as file:
    data = json.load(file)
  with open("lang_settings.json", "w") as file:
    data[str(guild.id)] = lang
    json.dump(data, file)

def get_language(guild : discord.Guild):
  with open("lang_settings.json", "r") as file:
    data = json.load(file)
    return Lang[data[str(guild.id)]]

