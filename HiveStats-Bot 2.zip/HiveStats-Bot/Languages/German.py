import discord

def playerBedwarsEmbedBuilder(data, author, playername=""):
  print("EMBED")
  embed = discord.Embed(title=f"Treasure Wars Statistiken - {playername}", color=discord.Color.gold())
  embed.add_field(name="XP", value=data.experience, inline=True)
  embed.add_field(name="Spiele gespielt", value=data.played, inline=True)
  embed.add_field(name="Gewonnen", value=data.victories, inline=True)
  embed.add_field(name="Erstes Mal gespielt", value=data.first_played, inline=True)
  embed.add_field(name="Finale Kills", value=data.final_kills, inline=True)
  embed.add_field(name="KIlls", value=data.kills, inline=True)
  embed.add_field(name="Schätze zerstört", value=data.treasures_destroyed, inline=True)
  embed.add_field(name="Tode", value=data.deaths, inline=True)
  embed.set_footer(text=f"Anfrage von {author}")
  print("EMBED2")
  return embed