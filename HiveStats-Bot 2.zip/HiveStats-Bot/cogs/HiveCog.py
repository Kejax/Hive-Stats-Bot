from Hive.Player import *
import discord
from discord.ext import commands
from Language import get_language, write_language
from Languages.German import playerBedwarsEmbedBuilder

bedwars_aliases = ["bw", "tw", "bedwars", "treasurewars"]

class HiveExtension(commands.Cog):

  def __init__(self, bot):
    self.bot = bot
  
  async def cog_check(self, ctx):
    return ctx.author.id == self.bot.author_id
  
  @commands.command()
  async def stats(self, ctx, mode, *, player=None):
    lang = get_language(ctx.guild)
    if player == None:
      await ctx.send("TEST")
      return
    
    
    if mode in bedwars_aliases:
      statistics = Bedwars(player)
    print(statistics)
    print("TEST2")
    embed = lang.playerBedwarsEmbedBuilder(statistics, ctx.author, player)
    await ctx.send(embed=embed)

def setup(bot):
  bot.add_cog(HiveExtension(bot))