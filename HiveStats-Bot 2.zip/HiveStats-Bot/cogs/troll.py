import discord
from discord.ext import commands
import asyncio

def get_user(mention):

  replace_ = ["<", "@", "!", ">"]
  for i in replace_:
   mention = mention.replace(i, "")

  return mention

class Admin(commands.Cog, name="Admin Commands"):
  """"""

  def __init__(self, bot):
    self.bot = bot


  async def cog_check(self, ctx):

    if ctx.guild.id is not 829111836019261531:
      
      embed = discord.Embed(title="Dieser Befehl ist nur auf Gaming Community verfügbar")
      await ctx.channel.send(embed=embed)
      return False

    admin_role = ctx.guild.get_role(829146547273990175)
    admin = None
    if ctx.author.top_role >= admin_role or ctx.author.id == self.bot.author_id:
      return True
    else:
      command = ctx.message.content.split(" ")[0]
      embed = discord.Embed(title=f"Du kannst den Befehl `{command}` nicht ausführen", color=15844367)
      await ctx.channel.send(embed=embed)
      return False


  @commands.command(name="ping")
  async def ping(self, ctx, user_ping, *, msg=None):
    """Pingt jemanden normal"""

    user_id = int(get_user(user_ping))
    user = self.bot.get_user(user_id)

    if user == ctx.author and user.id != self.bot.author_id:
      embed = discord.Embed(title="Du kannst dich nicht selbst pingen", color=15844367)
      await ctx.channel.send(embed=embed)
      return

    if user.id == self.bot.author_id and ctx.author.id != self.bot.author_id:
      embed = discord.Embed(title="Du kannst meinen Developer nicht pingen ;-P", color=15844367)
      await ctx.channel.send(embed=embed)
      return

    embed = discord.Embed(title=f"{ctx.guild.name} - Ping", color=15844367)
    embed.add_field(name="Ping", value=f"{ctx.author.name} will etwas von dir auf `{ctx.guild.name}`!", inline=False)

    if msg is not None:
      embed.add_field(name="Nachricht", value=msg, inline=False)

    await user.send(embed=embed)
    await ctx.channel.send(f"{user.name} wurde gepingt")
    print(f"{ctx.author.name} pinged {user.name}")
    return


  @commands.command(name="anonymping")
  async def anonymping(self, ctx, user_ping, *, msg=None):
    """Pingt jemanden anonym, ohne Hinweise auf den Pinger"""

    user_ping = str(user_ping)
    replace_ = ["<", "@", "!", ">"]
    user_ping = user_ping.replace("<", "")
    user_ping = user_ping.replace("@", "")
    user_ping = user_ping.replace("!", "")
    user_ping = user_ping.replace(">", "")
    user_id = int(user_ping)
    user = self.bot.get_user(user_id)

    if user == ctx.author and user.id != self.bot.author_id:
      embed = discord.Embed(title="Du kannst dich nicht selbst pingen", color=15844367)
      await ctx.channel.send(embed=embed)
      return

    if user.id == self.bot.author_id and ctx.author.id != self.bot.author_id:
      embed = discord.Embed(title="Du kannst meinen Developer nicht pingen ;-P", color=15844367)
      await ctx.channel.send(embed=embed)
      return

    embed = discord.Embed(title=f"{ctx.guild.name} - Anonymus Ping", color=15844367)
    embed.add_field(name="Ping", value=f"Jemand will etwas von dir auf `{ctx.guild.name}`!", inline=False)

    if msg is not None:
      embed.add_field(name="Nachricht", value=msg, inline=False)

    await user.send(embed=embed)
    own_msg = await ctx.channel.send(f"{user.name} wurde gepingt")
    print(f"{ctx.author.name} hidepinged {user.name}")
    await ctx.message.delete(delay=2)
    await own_msg.delete(delay=2)


  @commands.command(name="return")
  async def return_msg(self, ctx, *, msg):
    await ctx.channel.send(msg + "\nSended Message")


  @commands.Cog.listener("on_message")
  async def delete_msg(self, ctx):
    if "discord.gg" in ctx.content and ctx.author.id != 791432541939957762 and ctx.author.id != self.bot.author_id:
      await ctx.delete()

    if ctx.author == self.bot:
      return
    if ctx.guild:
      delete_role = ctx.guild.get_role(858834978107555921)
      if delete_role in ctx.author.roles:
        await ctx.delete()

def setup(bot):
  bot.add_cog(Admin(bot))