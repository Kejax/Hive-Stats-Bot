import discord
from discord.ext import commands, tasks
import requests
import json
from stats_embeds import *
from language_get import *
#from main import is_linked, get_link, write_link

def is_linked(discord_id):
  try:
    playerlink = db["playerlink-" + str(discord_id)]
    if not playerlink == None:
      return True
    else:
      return False
  except Exception:
    return False

def get_link(discord_id):
  playerlink = db["playerlink-" + str(discord_id)]
  return playerlink


def write_link(discord_id, player_name):
  db["playerlinks-" + str(discord_id)] = playername


class HiveStats(commands.Cog, name='HiveCommands'):

  def __init__(self, bot):
    self.bot = bot

  async def cog_check(self, ctx):
    if ctx.guild.id == 829706368302317619:
      return True
    else:
      return False

  @commands.command(name="allstats")
  async def stats(self, ctx, mode, *, player=None):

    if player is None:
      if is_linked(str(ctx.author.id)):
        player = get_link(str(ctx.author.id))
      else:
        #if lang(ctx.guild.id, "de"):
        await ctx.channel.send("Du hast keinen Spieler angegeben & bist auch nicht gelinkt")

    if player.startswith("<@!"):
      replace_ = ["<", "@", "!", ">"]
      for i in replace_:
        player = player.replace(i, "")

      player = get_link(player)


    Bedwars_alias = ["Bedwars", "bedwars", "bw", "BW", "tw", "TW"]
    Murder_alias = ["Murder", "murder", "Murdermystery", "murdermystery", "mm", "MM"]
    HidenSeek_alias = ["Hidenseek", "hidenseek", "hs", "HS", "hide", "Hide", "Hides", "hides"]
    Skywars_alias = ["Skywars" "skywars", "sw", "SW"]
    
    print(player)
    

    try:
    
    #if 1 == 1:
      #Bedwars / Treasurewars embed
      if mode in Bedwars_alias:
        await bedwars(ctx, player)
      #Murdermystery embed
      if mode in Murder_alias:
        stats_request = requests.get(f"https://api.playhive.com/v0/game/all/murder/{player}")
        stats = stats_request.json()

        Stats_Embed = discord.Embed(title=f"TheHive Stats - {player} - Murder Mystery", color=10038562)
        Stats_Embed.add_field(name="XP", value=stats["xp"], inline=False)
        Stats_Embed.add_field(name="Wins", value=stats["victories"], inline=True)
        Stats_Embed.add_field(name="Games", value=stats["played"], inline=True)
        Stats_Embed.add_field(name="Mörder", value=stats["murders"], inline=True)
        Stats_Embed.add_field(name="Deaths", value=stats["deaths"], inline=True)
        Stats_Embed.add_field(name="Mörder gekillt", value=stats["murderer_eliminations"], inline=True)
        Stats_Embed.add_field(name="Coins", value=stats["coins"], inline=True)
        Stats_Embed.set_footer(text="TheHive Stats Bot by Kejax Innovations\nhive/help für Hilfe", icon_url="https://www.dropbox.com/s/houd16570trau3v/Kejax_Inno_Logo.png?dl=1")
        await ctx.channel.send(embed=Stats_Embed)

      #Hide'n Seek embed
      if mode in HidenSeek_alias:
        stats_request = requests.get(f"https://api.playhive.com/v0/game/all/hide/{player}")    
        stats = stats_request.json()

        Stats_Embed = discord.Embed(title=f"TheHive Stats - {player} - Hide'n Seek", color=10038562)
        Stats_Embed.add_field(name="XP", value=stats["xp"], inline=False)
        Stats_Embed.add_field(name="Wins", value=stats["victories"], inline=True)
        Stats_Embed.add_field(name="Games", value=stats["played"], inline=True)
        Stats_Embed.add_field(name="Verstecker Kills", value=stats["hider_kills"], inline=True)
        Stats_Embed.add_field(name="Sucher Kills", value=stats["seeker_kills"], inline=True)
        Stats_Embed.set_footer(text="TheHive Stats Bot by Kejax Innovations\nhive/help für Hilfe", icon_url="https://www.dropbox.com/s/houd16570trau3v/Kejax_Inno_Logo.png?dl=1")
        await ctx.channel.send(embed=Stats_Embed)

        #Skywars embed
      if mode in Skywars_alias:
        stats_request = requests.get(f"https://api.playhive.com/v0/game/all/sky/{player}")    
        stats = stats_request.json()

        Stats_Embed = discord.Embed(title=f"TheHive Stats - {player} - SkyWars", color=15844367)
        Stats_Embed.add_field(name="XP", value=stats["xp"], inline=False)
        Stats_Embed.add_field(name="Wins", value=stats["victories"], inline=True)
        Stats_Embed.add_field(name="Games", value=stats["played"], inline=True)
        Stats_Embed.add_field(name="Kills", value=stats["kills"], inline=True)
        Stats_Embed.add_field(name="Erze abgebaut", value=stats["ores_mined"], inline=True)
        Stats_Embed.add_field(name="Zauber genutzt", value=stats["spells_used"], inline=True)
        Stats_Embed.add_field(name="Mystery Chests zerstört", value=stats["mystery_chests_destroyed"], inline=True)
        Stats_Embed.set_footer(text="TheHive Stats Bot by Kejax Innovations\nhive/help für Hilfe", icon_url="https://www.dropbox.com/s/houd16570trau3v/Kejax_Inno_Logo.png?dl=1")
        await ctx.channel.send(embed=Stats_Embed)
    
      
    except Exception:
        embed = discord.Embed(title=f"Entweder habe ich keine Daten für den Spieler `{player}` gefunden, oder du hast ihn falsch geschrieben (Groß-/Kleinschreibung wird nicht beachtet)", color=9807270)
        await ctx.channel.send(embed=embed)


  @commands.command(name="link")
  async def link(self, ctx, *, player=None):
    
    if player is not None:
      write_link(str(ctx.author.id), player)
      await ctx.channel.send(f"Du hast dich erfolgreich als Spieler `{player}` gelinkt.\nWenn du jetzt einen stats befehl benutzt, brauchst du keinen Namen angeben, wenn du deine stats sehen willst.")
    else:
      await ctx.channel.send(f"Der Spielername `{player}` konnte nicht mit dir gelinkt werden")


  
  @commands.command(name="help")
  async def help(self, ctx, mode=None):

    if mode is None:
      help_1 = "`hive/allstats <mode> <player>`\nZeigt dir deine gesamten Statistiken"
      help_2 = "`hive/link <player>`\nLinkt dich mit deinem Spielernamen"
    
      help_Embed = discord.Embed(title="TheHive Stats Bot - Help")
      help_Embed.add_field(name="allstats", value=help_1, inline=False)
      help_Embed.add_field(name="link", value=help_2, inline=False)
      help_Embed.set_footer(text="TBD")

      

    if mode == "modes":
      
      help_Embed = discord.Embed(title="Modies - Help")
      help_Embed.add_field

    await ctx.channel.send(embed=help_Embed)

  @commands.command(name="leaderboard")
  async def leaderboard(self, ctx, mode):
    ctx.channel.send("TBD")
    

  @commands.command(name="lang")
  async def lang(self, ctx):

    language_context_en = """
    Please react with one of the flags, to choose your Language:
    
    :flag_de: - German
    :flag_gb: - English

    More Languages in work
    """

    language_context_de = """
    Bitte reagiere mit einer der Flaggen, um die Sprache zu wechseln:

    :flag_de: - Deutsch
    :flag_gb: - Englisch

    Weiter Sprachen in Arbeit"""

    if get_lang(ctx.channel.guild.id) == None:
      lang_embed = discord.Embed(title="Language Setup", description=language_context_en)
      
    if get_lang(ctx.channel.guild.id) == "de":
      lang_embed = discord.Embed(title="Sprachwechsel", description=language_context_de)
    lmessage = await ctx.channel.send("t", embed=lang_embed)
    print(lang_message.id)
    await ctx.message.add_reaction()
    await message.add_reaction(":flag_gb:")

    write_lang_msg(ctx.channel.guild.id, lang_message.id)


  """@tasks.loop(seconds=1.0)
  async def version_status():
    await self.bot.change_presence(activity=discord.Game("V 0.1.1"), status=discord.Status.online)
    await asyncio.sleep(5)
    await self.bot.change_presence(activity=discord.Game("Hilfe? **hive/help**"), status=discord.Status.online)
    await asyncio.sleep(5)"""
    
  #@commands.Cog.listener("on_reaction_add")
  #async def on_reaction(self, reaction, user):

    #print(reaction.message.guild.owner)
    #print(user)
    
    #if user.id == reaction.message.guild.owner.id:
      #print("Test bestanden")

    #print("TBD")

  @commands.command(name="trello")
  async def trello(self, ctx):
    print(ctx.author.avatar_url)

  #@commands.Cog.listener("on_message")
  #async def message_reward(self, ctx):

    #if ctx.author.id == 791432541939957762:
     # await ctx.channel.send("@" + str(ctx.author.display_name) + " ok")
  


    
    



def setup(bot):
  bot.add_cog(HiveStats(bot))