import json


def is_linked(discord_id):

  linked_file = open("linked.json", "r")

  linked_json = linked_file.json()

  if discord_id in linked_json:
    return True


def get_link(discord_id):

  linked_file = open("linked_json", "r")

  linked_json = linked_file.json()

  return linked_json[discord_id]
